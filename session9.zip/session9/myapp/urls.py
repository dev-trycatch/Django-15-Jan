from django.urls import path
from .views import *
urlpatterns = [
    path('register/',register,name='register_view'),
    path('login/',login_view,name='login_view'),
    path('dashboard/',dashboard,name='dashboard'),
    path('logout/',logout_view,name='logout_view'),
]